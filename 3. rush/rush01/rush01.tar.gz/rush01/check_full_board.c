/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_full_board.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: gsuhr <gsuhr@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/10/07 13:03:49 by gsuhr             #+#    #+#             */
/*   Updated: 2023/10/07 14:41:01 by gsuhr            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	*array_generator(int a, int b, int c, int d);

int	check_left_or_top(int *m, int v)
{
	int	r;
	int	i;

	r = 0;
	i = 1;
	if (m[1] > m[0])
	{
		i++;
	}
	if (m[2] > m[0] && m[2] > m[1])
	{
		i++;
	}
	if (m[3] > m[2] && m[3] > m[1] && m[3] > m[0])
	{
		i++;
	}
	if (i == v)
	{
		r = 1;
	}
	return (r);
}

int	check_right_or_bottom(int *m, int v)
{
	int	r;
	int	i;

	r = 0;
	i = 1;
	if (m[2] > m[3])
	{
		i++;
	}
	if (m[1] > m[3] && m[1] > m[2])
	{
		i++;
	}
	if (m[0] > m[1] && m[0] > m[2] && m[0] > m[3])
	{
		i++;
	}
	if (i == v)
	{
		r = 1;
	}
	return (r);
}

int	check_all_rows(int **b, int inputs[])
{
	int	i;
	int	j;
	int	r;
	int	c;

	i = 0;
	j = 1;
	r = 0;
	c = 0;
	while (i < 4)
	{
		if (check_left_or_top(b[i], inputs[j + 8]) == 1)
			c++;
		if (check_right_or_bottom(b[i], inputs[j + 12]) == 1)
			c++;
		i++;
		j++;
	}
	if (c == 8)
	{
		r = 1;
	}
	return (r);
}

int	check_all_columns(int **b, int *inputs)
{
	int	i;
	int	j;
	int	r;
	int	c;
	int	*arr[4];

	i = 0;
	j = 1;
	c = 0;
	while (i < 4)
	{
		r = 0;
		*arr = array_generator(b[i][r], b[i][r + 1], b[i][r + 2], b[i][r + 3]);
		while (r < 4)
		{
			if (check_left_or_top(arr, inputs[j]) == 1)
				c++;
			if (check_right_or_bottom(arr, inputs[j + 4]) == 1)
				c++;
			r++;
		}
		i++;
		j++;
	}
	return (c);
}

int	check_full_board(int **board, int *inputs)
{
	int	r;

	r = 0;
	if (check_all_rows(board, inputs) == 1)
		r++;
	if (check_all_columns(board, inputs) == 8)
		r++;
	return (r);
}
